<?php
// archive.php - Template for Archive Pages
get_header();
?>

<div class="shawonbinrashid__archive container">
    <header class="shawonbinrashid__archive-header">
        <h1 class="shawonbinrashid__archive-title">
            <?php
            if (is_category()) {
                single_cat_title();
            } elseif (is_tag()) {
                single_tag_title();
            } elseif (is_author()) {
                echo 'Posts by ' . get_the_author();
            } elseif (is_date()) {
                echo get_the_date('F Y');
            } else {
                echo 'Archives';
            }
            ?>
        </h1>
        <?php if (is_category() || is_tag()) : ?>
            <p class="shawonbinrashid__archive-description"><?php echo term_description(); ?></p>
        <?php endif; ?>
    </header>

    <?php if (have_posts()) : ?>
        <div class="shawonbinrashid__archive-posts row">
            <?php while (have_posts()) : the_post(); ?>
                <div class="shawonbinrashid__archive-post col-md-4">
                    <div class="shawonbinrashid__card" style="background: linear-gradient(135deg, #f0f4ff, #ffffff);">
                        <a href="<?php the_permalink(); ?>" class="shawonbinrashid__card-img-link">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="shawonbinrashid__card-img-top">
                                    <?php the_post_thumbnail('medium', array('class' => 'shawonbinrashid__thumbnail', 'style' => 'width: 100%; height: 200px; object-fit: cover; border-radius: 8px 8px 0 0;')); ?>
                                </div>
                            <?php else : ?>
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/default-thumbnail.jpg" alt="Default Thumbnail" style="width:100%; height: 200px; object-fit: cover; border-radius: 8px 8px 0 0;">
                            <?php endif; ?>
                        </a>
                        <div class="shawonbinrashid__card-body">
                            <h2 class="shawonbinrashid__post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <div class="shawonbinrashid__post-meta">
                                <span class="shawonbinrashid__post-date"><i class="fas fa-calendar-alt"></i> <?php echo get_the_date(); ?></span>
                                <span class="shawonbinrashid__post-author"><i class="fas fa-user"></i> <?php the_author(); ?></span>
                            </div>
                            <p class="shawonbinrashid__post-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 15, '...'); ?></p>
                            <a href="<?php the_permalink(); ?>" class="shawonbinrashid__read-more">Read More</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <div class="shawonbinrashid__pagination">
            <?php
            echo paginate_links(array(
                'total' => $wp_query->max_num_pages,
                'prev_text' => '&laquo;',
                'next_text' => '&raquo;',
            ));
            ?>
        </div>

    <?php else : ?>
        <p class="shawonbinrashid__no-posts">Sorry, no posts found in this archive.</p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
