<?php
// tag.php - Template for Tag Archive Pages
get_header();
?>

<div class="shawonbinrashid__tag-archive container">
    <header class="shawonbinrashid__tag-header">
        <h1 class="shawonbinrashid__tag-title">
            <?php single_tag_title('Posts tagged: '); ?>
        </h1>
        <?php if (tag_description()) : ?>
            <p class="shawonbinrashid__tag-description"><?php echo tag_description(); ?></p>
        <?php endif; ?>
    </header>

    <?php if (have_posts()) : ?>
        <div class="shawonbinrashid__tag-posts row">
            <?php while (have_posts()) : the_post(); ?>
                <div class="shawonbinrashid__tag-post col-md-4">
                    <div class="shawonbinrashid__card" style="background: linear-gradient(135deg, #f5f8ff, #ffffff);">
                        <a href="<?php the_permalink(); ?>" class="shawonbinrashid__card-img-link">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="shawonbinrashid__card-img-top">
                                    <?php the_post_thumbnail('medium', array('class' => 'shawonbinrashid__thumbnail', 'style' => 'width: 100%; height: 200px; object-fit: cover; border-radius: 8px 8px 0 0;')); ?>
                                </div>
                            <?php else : ?>
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/default-thumbnail.jpg" alt="Default Thumbnail" style="width:100%; height: 200px; object-fit: cover; border-radius: 8px 8px 0 0;">
                            <?php endif; ?>
                        </a>
                        <div class="shawonbinrashid__card-body">
                            <h2 class="shawonbinrashid__post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <div class="shawonbinrashid__post-meta">
                                <span class="shawonbinrashid__post-date"><i class="fas fa-calendar-alt"></i> <?php echo get_the_date(); ?></span>
                                <span class="shawonbinrashid__post-author"><i class="fas fa-user"></i> <?php the_author(); ?></span>
                            </div>
                            <p class="shawonbinrashid__post-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 15, '...'); ?></p>
                            <a href="<?php the_permalink(); ?>" class="shawonbinrashid__read-more">Read More</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <div class="shawonbinrashid__pagination">
            <?php
            echo paginate_links(array(
                'total' => $wp_query->max_num_pages,
                'prev_text' => '&laquo;',
                'next_text' => '&raquo;',
            ));
            ?>
        </div>

    <?php else : ?>
        <p class="shawonbinrashid__no-posts">No posts found for this tag.</p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
