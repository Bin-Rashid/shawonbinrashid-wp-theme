<?php
define('ATTACHMENT_SETTINGS_SCREEN', false);
add_filter('attachments_default_instance', '__return_false'); 
function shawonbinrashid_testimonial_attachments($attachments) {
    $fields = array(
        array(
            'name'      => 'name',
            'type'      => 'text',
            'label'     => __( 'Name', 'shawonbinrashid' ),
        ),
        array(
            'name'      => 'designation',
            'type'      => 'text',
            'label'     => __( 'Designation', 'shawonbinrashid' ),
        ),
        array(
            'name'      => 'testimonial', // corrected
            'type'      => 'textarea',
            'label'     => __( 'Testimonial', 'shawonbinrashid' ), // corrected
        ),
    );

    $args = array(
        'label'         => 'Testimonials', // corrected
        'post_type'     => array('page'), // can also include 'post' or custom post types
        'filetype'      => array('image'),
        'note'          => 'Add Testimonials', // corrected
        'button_text'   => __( 'Attach Files', 'shawonbinrashid' ),
        'fields'        => $fields,
    );

    $attachments->register('testimonials', $args); // corrected
}
add_action('attachments_register', 'shawonbinrashid_testimonial_attachments');

