<?php
class My_Custom_Calendar_Widget extends WP_Widget {
    public function __construct() {
        // Widget options
        parent::__construct(
            'my_custom_calendar_widget',
            'Custom Calendar Widget',
            array('description' => 'A Custom Calendar Widget with navigation')
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];
        ?>
        <div id="calendar-widget">
            <!-- Calendar Content -->
            <div id="calendar-content">
                <?php
                // Your existing code for displaying the calendar
                ?>
            </div>
            <!-- Navigation Buttons -->
            <div class="calendar-navigation">
                <button id="prev-month" class="calendar-nav-btn">« Sep</button>
                <button id="next-month" class="calendar-nav-btn">Nov »</button>
            </div>
        </div>
        <?php
        echo $args['after_widget'];
    }
}
