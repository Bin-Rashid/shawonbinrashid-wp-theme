<!-- footer section Start -->
<section id="footer">
    <div class="container">
        <div class="footer_item text-center">
            <!-- Footer Logo -->
            <div class="footer_logo_box">
                <?php if (get_theme_mod('footer_logo_type') === 'image' && get_theme_mod('footer_logo_image')) : ?>
                    <a href="<?php echo esc_url(home_url()); ?>" class="footer_logo">
                        <img src="<?php echo esc_url(get_theme_mod('footer_logo_image')); ?>" alt="Footer Logo">
                    </a>
                <?php else : ?>
                    <a href="<?php echo esc_url(home_url()); ?>" class="footer_logo">
                        <span><?php echo esc_html(get_theme_mod('footer_logo_text_part1', 'Shawon')); ?></span>
                        <?php echo esc_html(get_theme_mod('footer_logo_text_part2', 'Ahmed')); ?>
                    </a>
                <?php endif; ?>
            </div>

            <!-- Social Icons -->
            <div class="footer_social">
                <ul class="footer_item_list">
                    <?php
                    $social_links_json = get_theme_mod('footer_social_links', '[{"icon": "fa-facebook-f", "url": "#"}, {"icon": "fa-twitter", "url": "#"}]');
                    $social_links = json_decode($social_links_json, true);
                    if ($social_links) :
                        foreach ($social_links as $link) :
                            $icon = esc_attr($link['icon']);
                            $url = esc_url($link['url']);
                            ?>
                            <li><a href="<?php echo $url; ?>" target="_blank"><i class="fa-brands <?php echo $icon; ?>"></i></a></li>
                        <?php endforeach;
                    endif;
                    ?>
                </ul>
            </div>

            <!-- Copyright Text -->
            <div class="copy_right">
                <p class="cpyr"><?php echo esc_html(get_theme_mod('footer_copyright_text', '© 2024 Shawon Ahmed. All Rights Reserved')); ?></p>
            </div>
        </div>
    </div>
</section>


<!-- footer section end -->

<?php wp_footer(); ?>
</body>
</html>
