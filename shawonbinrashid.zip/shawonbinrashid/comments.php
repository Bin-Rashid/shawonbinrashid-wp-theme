<?php
if ( post_password_required() ) {
    return;
}
?>

<div id="comments" class="comments-area">
    <?php if ( have_comments() ) : ?>
        <h2 class="comments-title">
            <?php
            $comment_count = get_comments_number();
            printf(
                esc_html( _n( '%1$s Comment', '%1$s Comments', $comment_count, 'your-text-domain' ) ),
                number_format_i18n( $comment_count )
            );
            ?>
        </h2>

        <ol class="comment-list">
            <?php
            wp_list_comments( array(
                'style'       => 'ol',
                'short_ping'  => true,
                'avatar_size' => 60,
                'callback'    => 'custom_comment_callback', // Custom callback for comment structure
            ) );
            ?>
        </ol>

        <?php the_comments_navigation(); ?>

    <?php endif; ?>

    <?php if ( ! comments_open() ) : ?>
        <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'your-text-domain' ); ?></p>
    <?php endif; ?>

    <?php
    comment_form( array(
        'title_reply' => 'Leave a Comment',
    ) );
    ?>
</div>

<!-- Edit Comment Popup -->
<div id="edit-comment-popup" style="display:none; background: #243642; padding: 20px; border-radius: 10px; border: 2px solid #E2F1E7; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999;">
    <h3 class="edit__comment_title"><?php _e("Edit Comment","errorfixer") ?></h3>
    <input type="hidden" id="edit-comment-id">
    <textarea id="edit-comment-content" rows="4" cols="50" style="padding: 5px; margin: 0;"></textarea>
    <br>
    <button id="submit-edit-comment">Update Comment</button>
    <button id="close-popup">Close</button>
</div>

