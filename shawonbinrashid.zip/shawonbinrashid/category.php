<?php
// category.php - Template for Category Archive
get_header();
?>

<div class="shawonbinrashid__category-archive container">
    <header class="shawonbinrashid__archive-header">
        <h1 class="shawonbinrashid__archive-title"><?php single_cat_title(); ?></h1>
        <p class="shawonbinrashid__archive-description"><?php echo category_description(); ?></p>
    </header>

    <?php if (have_posts()) : ?>
        <div class="shawonbinrashid__archive-posts row">
            <?php while (have_posts()) : the_post(); ?>
                <div class="shawonbinrashid__archive-post col-md-4">
                    <div class="shawonbinrashid__card" style="background: linear-gradient(145deg, #f3f0ff, #ffffff, #e8e4ff);">
                        <div class="shawonbinrashid__card-img-top">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium', array('style' => 'width:100%; border-radius: 8px 8px 0 0;')); ?>
                            <?php else : ?>
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/default-thumbnail.jpg" alt="Default Thumbnail" style="width:100%; border-radius: 8px 8px 0 0;">
                            <?php endif; ?>
                        </div>
                        <div class="shawonbinrashid__card-body">
                            <h2 class="shawonbinrashid__post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <div class="shawonbinrashid__post-meta">
                                <span class="shawonbinrashid__post-date"><i class="fas fa-calendar-alt"></i> <?php echo get_the_date(); ?></span> |
                                <span class="shawonbinrashid__post-author"><i class="fas fa-user"></i> <?php the_author(); ?></span>
                            </div>
                            <p class="shawonbinrashid__post-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
                            <a href="<?php the_permalink(); ?>" class="shawonbinrashid__read-more">Read More</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <div class="shawonbinrashid__pagination">
            <?php
            echo paginate_links(array(
                'total' => $wp_query->max_num_pages,
                'prev_text' => '&laquo;',
                'next_text' => '&raquo;',
            ));
            ?>
        </div>

    <?php else : ?>
        <p class="shawonbinrashid__no-posts">Sorry, no posts found in this category.</p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
