<?php get_header(); ?>

<div class="container mt-4">
    <!-- Navigation Bar -->
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <!-- Home Icon -->
        <li class="breadcrumb-item">
            <a href="<?php echo esc_url(home_url()); ?>"><i class="fas fa-home"></i> Home</a>
        </li>

        <?php
        // Check if we are on a single post
        if (is_single()) {
            // Display the Blog link
            echo '<li class="breadcrumb-item"><a href="' . esc_url(get_permalink(get_option('page_for_posts'))) . '">Blog</a></li>';
            
            // Get the categories
            $categories = get_the_category();
            if (!empty($categories)) {
                $category = $categories[0];
                echo '<li class="breadcrumb-item"><a href="' . esc_url(get_category_link($category->term_id)) . '">' . esc_html($category->name) . '</a></li>';
            }

            // Display the post title (linked)
            echo '<li class="breadcrumb-item active" aria-current="page"><a href="' . esc_url(get_permalink()) . '">' . get_the_title() . '</a></li>';

        // Check if we are on a category archive
        } elseif (is_category()) {
            $category = get_queried_object();
            echo '<li class="breadcrumb-item active" aria-current="page">' . esc_html($category->name) . '</li>';

        // Check if we are on a tag archive
        } elseif (is_tag()) {
            $tag = get_queried_object();
            echo '<li class="breadcrumb-item active" aria-current="page">Tag: ' . esc_html($tag->name) . '</li>';

        // Check if we are on a search page
        } elseif (is_search()) {
            echo '<li class="breadcrumb-item active" aria-current="page">Search Results for "' . get_search_query() . '"</li>';

        // Check if we are on an archive (by author, date, etc.)
        } elseif (is_archive()) {
            echo '<li class="breadcrumb-item active" aria-current="page">' . post_type_archive_title('', false) . '</li>';

        // Check if we are on a page with parents (hierarchical structure)
        } elseif (is_page() && $post->post_parent) {
            // Get the ancestors of the current page
            $ancestors = array_reverse(get_post_ancestors($post->ID));
            foreach ($ancestors as $ancestor) {
                echo '<li class="breadcrumb-item"><a href="' . esc_url(get_permalink($ancestor)) . '">' . get_the_title($ancestor) . '</a></li>';
            }
            // Current page title
            echo '<li class="breadcrumb-item active" aria-current="page"><a href="' . esc_url(get_permalink()) . '">' . get_the_title() . '</a></li>';

        // Display title for standalone pages
        } elseif (is_page()) {
            echo '<li class="breadcrumb-item active" aria-current="page"><a href="' . esc_url(get_permalink()) . '">' . get_the_title() . '</a></li>';

        // Fallback for the blog page
        } elseif (is_home()) {
            echo '<li class="breadcrumb-item active" aria-current="page">Blog</li>';
        
        // Fallback for 404 page
        } elseif (is_404()) {
            echo '<li class="breadcrumb-item active" aria-current="page">404 Error</li>';
        }
        ?>
    </ol>
</nav>


    <!-- Post Banner -->
    <div class="shawonbinrashid__post-banner mb-4">
        <?php if (has_post_thumbnail()) : ?>
            <img class="img-fluid" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>" style="border-radius: 15px;">
        <?php endif; ?>
    </div>

    <!-- Post Title -->
    <h1 class="shawonbinrashid__post-title" style="font-size: 60px;"><?php the_title(); ?></h1>

    <!-- Post Meta -->
    <div class="row shawonbinrashid__post-meta mb-3">
    <div class="col-md-12">
        <span><?php echo get_reading_time(); ?> | </span>
        <span><?php the_category(', '); ?></span>
        </div>
    </div>


    <!-- Author Info -->
    <div class="row mb-3 shawonbinrashid__author-info">
        <div class="col-md-12 d-flex align-items-center">
            <div class="shawonbinrashid__author-image me-3">
                <?php echo get_avatar(get_the_author_meta('ID'), 60); ?>
            </div>
            <div>
                <h5 class="shawonbinrashid__author-name"><?php the_author_meta('display_name');  ?></h5>
                <span class="shawonbinrashid__author-designation"><?php the_author_meta('user_email'); ?></span>
            </div>
            <div class="ms-auto">
                <span><i class="fas fa-share-alt"></i></span>
            </div>
        </div>
    </div>

    <!-- Post Content -->
    <div class="shawonbinrashid__post-content mb-4">
        <?php the_content(); ?>
    </div>

    <!-- Post Tags -->
    <div class="shawonbinrashid__post-tags mb-4">
        <span>Posted in: </span>
        <?php the_tags('', ', '); ?>
    </div>

    <!-- Comments Section -->
    <div class="col-md-12 mb-4">
        <?php 
        if (!post_password_required() && comments_open()) :
            comments_template();
        endif; 
        ?>
    </div>

    <!-- Related Posts Slider -->
<div class="shawonbinrashid__related-posts">
    <h2 class="shawonbinrashid__related_post_title">Related Posts</h2>
    <div class="related-posts-slider">
        <?php
        // Query for related posts
        $related_posts = get_posts(array(
            'category__in' => wp_get_post_categories(get_the_ID()),
            'post__not_in' => array(get_the_ID()),
            'posts_per_page' => 10, // Number of related posts
        ));
        if ($related_posts) : ?>
            <?php foreach ($related_posts as $post) : setup_postdata($post); ?>
                <div class="shawonbinrashid__related-post card">
                    <a href="<?php the_permalink(); ?>">
                        <?php if (has_post_thumbnail()) : ?>
                            <img class="card-img-top" src="<?php echo get_the_post_thumbnail_url(); ?>" alt="<?php the_title(); ?>">
                        <?php else : ?>
                            <img class="card-img-top" src="<?php echo esc_url(get_template_directory_uri() . '/images/shawonbinrashid-default-image-blog-thumbnail.png'); ?>" alt="Default Image">
                        <?php endif; ?>
                    </a>
                    <div class="card-body">
                        <h5 class="shawonbinrashid__related-post-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h5>
                        <div class="shawonbinrashid__related-post-author-info d-flex align-items-center mb-2">
                            <?php echo get_avatar(get_the_author_meta('ID'), 30); ?>
                            <span class="shawonbinrashid__related-post-author-name ms-2"><?php the_author(); ?></span>
                        </div>
                        <p class="shawonbinrashid__related-post-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                        <a href="<?php the_permalink(); ?>" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php wp_reset_postdata(); ?>
        <?php endif; ?>
    </div>
</div>

</div>

<?php get_footer(); ?>
