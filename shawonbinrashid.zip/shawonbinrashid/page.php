<?php get_header(); ?>
    
<?php get_header(); ?>

<section id="page-banner" class="my-5">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-lg-8 col-md-10 text-center">
                <div class="banner-content p-4 rounded" style="border-radius: 15px; background-color: #f8f9fa;">
                    <!-- Dynamic Banner Image -->
                    <?php if (has_post_thumbnail()) : ?>
                        <img src="<?php the_post_thumbnail_url('large'); ?>" class="img-fluid rounded mb-4" alt="<?php the_title(); ?>" style="border-radius: 15px;">
                    <?php else : ?>
                        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/default-banner.jpg" class="img-fluid rounded mb-4" alt="Default Banner" style="border-radius: 15px;">
                    <?php endif; ?>

                    <!-- Dynamic Banner Title -->
                    <h1 class="banner-title"><?php the_title(); ?></h1>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Page Content Section -->
<section id="page-content" class="my-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-10">
                <div class="content-area">
                    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                        <?php the_content(); ?>
                    <?php endwhile; endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>

            
    <?php get_footer(); ?>