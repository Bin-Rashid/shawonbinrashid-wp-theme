<?php get_header(); ?>

<div class="container mt-4">
    <!-- Navigation Bar -->
    <!-- Navigation Bar -->
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <!-- Home Icon -->
        <li class="breadcrumb-item">
            <a href="<?php echo esc_url(home_url()); ?>"><i class="fas fa-home"></i> Home</a>
        </li>

        <?php
        // Check if we are on a single post
        if (is_single()) {
            // Display the Blog link
            echo '<li class="breadcrumb-item"><a href="' . esc_url(get_permalink(get_option('page_for_posts'))) . '">Blog</a></li>';
            
            // Get the categories
            $categories = get_the_category();
            if (!empty($categories)) {
                $category = $categories[0];
                echo '<li class="breadcrumb-item"><a href="' . esc_url(get_category_link($category->term_id)) . '">' . esc_html($category->name) . '</a></li>';
            }

            // Display the post title (linked)
            echo '<li class="breadcrumb-item active" aria-current="page"><a href="' . esc_url(get_permalink()) . '">' . get_the_title() . '</a></li>';

        // Check if we are on a category archive
        } elseif (is_category()) {
            $category = get_queried_object();
            echo '<li class="breadcrumb-item active" aria-current="page">' . esc_html($category->name) . '</li>';

        // Check if we are on a tag archive
        } elseif (is_tag()) {
            $tag = get_queried_object();
            echo '<li class="breadcrumb-item active" aria-current="page">Tag: ' . esc_html($tag->name) . '</li>';

        // Check if we are on a search page
        } elseif (is_search()) {
            echo '<li class="breadcrumb-item active" aria-current="page">Search Results for "' . get_search_query() . '"</li>';

        // Check if we are on an archive (by author, date, etc.)
        } elseif (is_archive()) {
            echo '<li class="breadcrumb-item active" aria-current="page">' . post_type_archive_title('', false) . '</li>';

        // Check if we are on a page with parents (hierarchical structure)
        } elseif (is_page() && $post->post_parent) {
            // Get the ancestors of the current page
            $ancestors = array_reverse(get_post_ancestors($post->ID));
            foreach ($ancestors as $ancestor) {
                echo '<li class="breadcrumb-item"><a href="' . esc_url(get_permalink($ancestor)) . '">' . get_the_title($ancestor) . '</a></li>';
            }
            // Current page title
            echo '<li class="breadcrumb-item active" aria-current="page"><a href="' . esc_url(get_permalink()) . '">' . get_the_title() . '</a></li>';

        // Display title for standalone pages
        } elseif (is_page()) {
            echo '<li class="breadcrumb-item active" aria-current="page"><a href="' . esc_url(get_permalink()) . '">' . get_the_title() . '</a></li>';

        // Fallback for the blog page
        } elseif (is_home()) {
            echo '<li class="breadcrumb-item active" aria-current="page">Blog</li>';
        
        // Fallback for 404 page
        } elseif (is_404()) {
            echo '<li class="breadcrumb-item active" aria-current="page">404 Error</li>';
        }
        ?>
    </ol>
</nav>

    <div class="row">
        <!-- Blog Area -->
<div class="col-md-8">
    <h1 class="mb-4">Blog</h1>
    <div class="row">
        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>
                <div class="col-md-6 mb-4">
                    <div class="shawonbinrashid__card shawonbinrashid__card--h-100"> <!-- Added h-100 class for equal height -->
                        <?php if ( has_post_thumbnail() ) : ?>
                            <a href="<?php the_permalink(); ?>">
                                <img class="shawonbinrashid__card__img-top" src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" alt="<?php the_title(); ?>">
                            </a>
                        <?php else : ?>
                            <a href="<?php the_permalink(); ?>">
                                <img class="shawonbinrashid__card__img-top" src="<?php echo esc_url(get_template_directory_uri() . '/images/shawonbinrashid-default-image-blog-thumbnail.png'); ?>" alt="Default blog image">
                            </a>
                        <?php endif; ?>
                        <div class="shawonbinrashid__card__body d-flex flex-column"> <!-- Added flex-column for better layout -->
                            <h5 class="shawonbinrashid__card__title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h5>
                            <div class="shawonbinrashid__post-meta mb-2">
                                <?php echo get_avatar( get_the_author_meta('ID'), 32 ); ?>
                                <span><?php the_author(); ?></span>
                                <span> | </span>
                                <span><?php the_time('F j, Y'); ?></span>
                            </div>
                            <p class="shawonbinrashid__card__text flex-grow-1"><?php the_excerpt(); ?></p> <!-- Use full text without ellipsis -->
                            <a href="<?php the_permalink(); ?>" class="shawonbinrashid__btn">Read More</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else : ?>
            <p><?php esc_html_e( 'Sorry, no posts found.' ); ?></p>
        <?php endif; ?>
    </div>
    <!-- Pagination -->
    <div class="shawonbinrashid__pagination">
        <?php
        // Custom Pagination
        the_posts_pagination(array(
            'prev_text' => __('&laquo; Previous', 'shawonbinrashid'),
            'next_text' => __('Next &raquo;', 'shawonbinrashid'),
            'mid_size' => 2, // Show 2 page numbers before and after the current page
        ));
        ?>
    </div>
</div>


        <!-- Sidebar Area -->
        <div class="col-md-4">
            <?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
                <div class="shawonbinrashid__sidebar">
                    <?php dynamic_sidebar( 'sidebar-1' ); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<?php get_footer(); ?>
