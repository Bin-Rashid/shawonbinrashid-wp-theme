<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- font -->
    <link href="https://fonts.googleapis.com/css2?family=Covered+By+Your+Grace&family=Raleway:wght@400;500;600;700;800&display=swap" rel="stylesheet"> 
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
