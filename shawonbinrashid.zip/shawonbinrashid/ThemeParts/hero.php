
<!-- banner section start -->
<section id="banner">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="row">
              <div class="col-md-12">
                <div class="banner_item">
                  <div class="my_img">
                  <img src="<?php echo esc_url(get_theme_mod('hero_image', get_theme_file_uri('images/my_img.png'))); ?>" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="banner_item">
              <div class="my_description">
                <h3>
                    <span><?php echo esc_html(get_theme_mod('person_first_name', 'Shawon')); ?></span>
                    <?php echo esc_html(get_theme_mod('person_last_name', 'Ahmed')); ?>
                </h3> 
                <h4>I'm <span class="type"> </span></h4>
                <p><?php echo esc_html(get_theme_mod('person_description', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sit ea, sint veritatis est ullam debitis harum. Minima laborum, nam tenetur amet ad error ipsam laboriosam!')); ?></p>

                 <div class="hire_social">
                  <div class="hire_area">
                    <a class="hire_me_btn" href="#" download="Shawon's Resume">Hire Me <i class="fa-solid fa-user"></i></a>
                  </div>
                  
                  <div class="my_social_area">
                    <?php
                    $social_media_links = get_theme_mod('shawonbinrashid_social_media', '[]');
                    $social_media_links = json_decode($social_media_links, true);

                    if (!empty($social_media_links)) {
                        foreach ($social_media_links as $link) {
                            if (!empty($link['icon']) && !empty($link['url'])) {
                                echo '<a class="social_m_btn" href="' . esc_url($link['url']) . '" target="_blank">';
                                echo '<i class="fa-brands fa-' . esc_attr($link['icon']) . ' h_color"></i>';
                                echo '</a>';
                            }
                        }
                    }
                    ?>
                </div>

                 </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- banner section end -->