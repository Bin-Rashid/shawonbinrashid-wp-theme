<!-- nav section start -->
<nav class="navbar navbar-expand-lg">
  <div class="container">
    <a class="navbar-brand" href="<?php echo esc_url(home_url()); ?>">
      <?php if (get_theme_mod('logo_type', 'text') === 'image' && get_theme_mod('image_logo')) : ?>
          <img src="<?php echo esc_url(get_theme_mod('image_logo')); ?>" alt="<?php bloginfo('name'); ?> Logo">
      <?php else : ?>
        
          <span><?php echo esc_html(get_theme_mod('text_logo_first_part', 'Shawon')); ?></span>
          <?php echo esc_html(get_theme_mod('text_logo_second_part', 'Ahmed')); ?>
      <?php endif; ?>
  </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="toggle_bar"><i class="fa-solid fa-barcode"></i></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <?php
        wp_nav_menu(array(
          'theme_location' => 'primary_menu',
          'menu_class'     => 'navbar-nav ms-auto mb-2 mb-lg-0',
          'container'      => false,
          'walker'         => new WP_Bootstrap_Navwalker(),
          'depth'          => 3,
        ));
      ?>
    </div>

    <!-- Dynamic Search Form -->
            <form class="d-flex search-form" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                <input class="form-control me-2" type="search" placeholder="Search..." aria-label="Search" name="s" value="<?php echo get_search_query(); ?>">
                <button class="btn btn-outline-primary" type="submit"><i class="fa fa-search"></i></button>
            </form>
  </div>
</nav>

<!-- nav section end -->