<?php
get_header();  // Display the site header
?>

<main class="error-404 not-found">
    <section class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h1 class="error-title">Oops! Page Not Found</h1>
                <p class="error-message">Sorry, but the page you were looking for doesn't exist or has been moved.</p>
                
                <!-- SVG Animation Section -->
                <div class="error-svg-container">
                    <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 100 100" class="svg-404">
                        <circle cx="50" cy="50" r="40" stroke="black" stroke-width="3" fill="yellow"/>
                        <circle cx="35" cy="40" r="5" fill="black"/>
                        <circle cx="65" cy="40" r="5" fill="black"/>
                        <path d="M30 60 Q50 80, 70 60" stroke="black" stroke-width="3" fill="transparent"/>
                        <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="3s" repeatCount="indefinite"/>
                    </svg>
                </div>

                <a href="<?php echo esc_url(home_url('/')); ?>" class="back-home-btn btn btn-primary">
                    Go Back to Homepage
                </a>
            </div>
        </div>
    </section>
</main>

<?php
get_footer();  // Display the site footer
?>
