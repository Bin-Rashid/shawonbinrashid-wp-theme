<?php
/*
 * Template Name: Home Page Template
 */
?>

<?php get_header(); ?>
<?php get_template_part("ThemeParts/nav") ?>
<?php get_template_part("ThemeParts/hero") ?>
    

    <!-- about section start -->
    <section id="about">
      <div class="container">
        <div class="about_bubble1">
          <div class="about_bubble2"></div>
      </div>
            <div class="about_heading text-center">
              <h3 class="title_circle"><span>About</span> Me</h3>
              <h4>I design and code beautiful things, and I love what I do.</h4>
            </div>

            <div class="row ">
              <div class="col-md-6">
                <div class="about_my_img">
                <img src="<?php echo esc_url(get_theme_mod('about__image', get_theme_file_uri('images/about (1).jpg'))); ?>">
                  
                </div>
              </div>

              <div class="col-md-6">
                <div class="about_item">
                  <span class="greeting_span">Hello i'm</span>
                  <?php
                    $about_section_data = get_post_meta(get_the_ID(), '_about_section_data', true);
                    $about_items = json_decode($about_section_data, true);

                    if ($about_items) : ?>
                        <div class="row">
                            <?php foreach ($about_items as $item) : ?>
                                <div class="col-md-6">
                                    <div class="about_icon">
                                        <div class="img_over_item">
                                            <img src="<?php echo esc_url(get_theme_file_uri('images/about_circle.png')); ?>" alt="about circle img">
                                            <div class="about_img_icon">
                                                <i class="fa <?php echo esc_attr($item['icon']); ?>"></i>
                                            </div>
                                        </div>
                                        <h2><?php echo esc_html($item['label']); ?>: <span><?php echo esc_html($item['value']); ?></span></h2>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                  <div class="about_btn">
                    <a href="#" class="resume_btn" download="shawon's resume">Download CV <i class="fa-solid fa-download"></i></a>
                  </div>
                </div>
              </div>
            </div>
      </div>
    </section>
    <!-- about section end -->

    <!-- services section start -->
<section id="services">
  <div class="container">
    <div class="services_bubble1"></div>
    <div class="services_bubble2"></div>
    <div class="services_bubble3"></div>

    <div class="services_heading text-center">
      <h3 class="title_circle"><span>Services </span>You May Need!</h3>
      <h4>I design and develop services for customers of all sizes.</h4>
    </div>
    
    <div class="row">
      <?php for ($i = 1; $i <= 6; $i++) : ?>
        <div class="col-md-4">
          <div class="services__itemContainer">
          <div class="services_item text-center">
            <div class="services_circle">
              <img src="<?php echo get_template_directory_uri(); ?>/images/services_icon.png" class="img-fluid services_circle_1">
              <?php $service_icon = get_theme_mod("service_icon_$i"); ?>
              <span class="services_item_img">
                <?php if ($service_icon) : ?>
                  <img src="<?php echo esc_url($service_icon); ?>" alt="Service Icon <?php echo $i; ?>" class="img-fluid">
                <?php endif; ?>
              </span>
            </div>
            <div class="services_item_detail">
              <h3><?php echo esc_html(get_theme_mod("service_title_$i", "Service Title $i")); ?></h3>
              <p><?php echo esc_html(get_theme_mod("service_description_$i", "Service description goes here.")); ?></p>
            </div>
          </div>
          </div>
        </div>
      <?php endfor; ?>
    </div>
  </div>
</section>
<!-- services section end -->



    <!-- Project section start -->
<section id="project">
    <div class="container">
        <div class="project_heading text-center">
            <h3 class="title_circle"><span>Project </span>I have completed.</h3>
            <h4>You Wanna see my Project! here it is.</h4>
        </div>

        <div class="row">
            <?php
            // Project metrics
            $metrics = array(
                'projects_completed' => 'Project completed',
                'happy_clients'      => 'Happy Client',
                'cups_of_coffee'     => 'Cup Of Coffee',
                'total_awards'       => 'Total Awards'
            );

            foreach ($metrics as $key => $label) {
                $icon = get_theme_mod("{$key}_icon");
                $count = get_theme_mod("{$key}_count", 0); // Default to 0 if not set
                ?>
                <div class="col-md-3">
                    <div class="project_item">
                        <div class="project_item_icon_name">
                            <?php if ($icon) : ?>
                                <img src="<?php echo esc_url($icon); ?>" alt="<?php echo esc_attr($label); ?>" class="img-fluid">
                            <?php endif; ?>
                            <h4><?php echo esc_html($label); ?></h4>
                            <span class="project_item_count">+<span class="counter"><?php echo esc_html($count); ?></span></span>
                        </div>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</section>
<!-- Project section end -->


    <!-- portfolio section start -->
<section id="portfolio">
    <div class="container">
        <div class="portfolio_heading">
            <h3 class="title_circle"><span>Portfolio </span>Section.</h3>
            <h4>You Wanna see my Project! here it is.</h4>
        </div>
        <div class="row">
            <?php for ($i = 1; $i <= 6; $i++) : ?>
                <div class="col-md-4">
                    <div class="portfolio_item">
                        <a href="#"><img src="<?php echo esc_url(get_theme_mod("portfolio_image_$i", '')); ?>" alt="portfolio img" class="img-fluid"></a>
                        <div class="portfolio_overlay">
                            <div class="overlay_icon">
                                <a href="<?php echo esc_url(get_theme_mod("portfolio_image_$i", '')); ?>" class="venobox" data-gall="myGallery"><i class="fa-solid fa-link-slash"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>
        </div>
    </div>
</section>
<!-- portfolio section end -->


   <!-- skill section start -->
<section id="skill">
    <div class="container">
        <div class="skill_heading text-center">
            <h3 class="title_circle"><span>Skills </span>that represent me.</h3>
            <h4>I Develop Skills Regularly to Keep Me Update.</h4>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="skill_item">
                    <div class="progress_item">
                        <?php for ($i = 1; $i <= 3; $i++) : ?>
                            <div class="skill_item">
                                <div class="skill_image">
                                    <img src="<?php echo esc_url(get_theme_mod("skill_image_$i", '')); ?>" alt="<?php echo esc_attr(get_theme_mod("skill_title_$i", '')); ?>">
                                </div>
                                <span><?php echo esc_html(get_theme_mod("skill_title_$i", '')); ?></span>
                                <div class="progress-bar" data-percentage="<?php echo esc_html(get_theme_mod("skill_percentage_$i", 0)); ?>"></div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="skill_item">
                    <div class="progress_item">
                        <?php for ($i = 4; $i <= 6; $i++) : ?>
                            <div class="skill_item">
                                <div class="skill_image">
                                    <img src="<?php echo esc_url(get_theme_mod("skill_image_$i", '')); ?>" alt="<?php echo esc_attr(get_theme_mod("skill_title_$i", '')); ?>">
                                </div>
                                <span><?php echo esc_html(get_theme_mod("skill_title_$i", '')); ?></span>
                                <div class="progress-bar" data-percentage="<?php echo esc_html(get_theme_mod("skill_percentage_$i", 0)); ?>"></div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- skill section end -->


    <!-- Testimonials section start -->
    <section id="testimonials">
      <div class="container">
        <div class="testimonials_heading">
          <h3 class="title_circle"><span>Testimonials , </span>clint's perspective!</h3>
          <h4>I Develop Skills Regularly to Keep Me Update.</h4>
        </div>
            <div class="testimonials_item">
              <div class="testimonials_slide">
                  <?php
                  $attachments = new Attachments('testimonials'); // Load attachments for 'testimonials'
                  if ($attachments->exist()) {
                      while ($attachments->get()) { ?>
                          <div class="hfgf">
                              <div class="client_img">
                                  <?php echo $attachments->image('thumbnail', array('class' => 'img-fluid', 'width' => '100%', 'height' => '100%')); ?>
                                  <div class="client_name">
                                      <h5><?php echo esc_html($attachments->field('name')); ?></h5>
                                      <p><?php echo esc_html($attachments->field('designation')); ?></p>
                                  </div>
                              </div>
                              <div class="client_filings">
                                  <span class="quote">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="var(--main-color)" class="bi bi-quote" viewBox="0 0 16 16">
                                          <path d="M12 12a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1h-1.388c0-.351.021-.703.062-1.054.062-.372.166-.703.31-.992.145-.29.331-.517.559-.683.227-.186.516-.279.868-.279V3c-.579 0-1.085.124-1.52.372a3.322 3.322 0 0 0-1.085.992 4.92 4.92 0 0 0-.62 1.458A7.712 7.712 0 0 0 9 7.558V11a1 1 0 0 0 1 1h2Zm-6 0a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1H4.612c0-.351.021-.703.062-1.054.062-.372.166-.703.31-.992.145-.29.331-.517.559-.683.227-.186.516-.279.868-.279V3c-.579 0-1.085.124-1.52.372a3.322 3.322 0 0 0-1.085.992 4.92 4.92 0 0 0-.62 1.458A7.712 7.712 0 0 0 3 7.558V11a1 1 0 0 0 1 1h2Z"/>
                                      </svg>
                                  </span>
                                  <p><?php echo esc_html($attachments->field('testimonial')); ?></p>
                                  <div class="rating text-center">
                                      <i class="fa-solid fa-star"></i>
                                      <i class="fa-solid fa-star"></i>
                                      <i class="fa-solid fa-star"></i>
                                      <i class="fa-regular fa-star"></i>
                                      <i class="fa-regular fa-star"></i>
                                  </div>
                              </div>
                          </div>
                      <?php }
                  } else {
                      echo "<p>No testimonials available.</p>";
                  }
                  ?>
              </div>

            </div>
      </div>
    </section>
    <!-- Testimonials section ebd -->

    <!-- blog section start -->
<section id="blog">
  <div class="container">
    <div class="blog_heading">
      <h3 class="title_circle"><span>Blog , </span>Published for you!</h3>
      <h4>You Can Read All My Blog From Here.</h4>
    </div>
    <div class="row">
      <?php
        // Adjust the query to fetch only 3 latest posts
        $args = array(
          'posts_per_page' => 5, // Show 3 latest posts
          'post_status' => 'publish' // Only show published posts
        );
        $latest_posts = new WP_Query($args);

        if ($latest_posts->have_posts()) :
          while ($latest_posts->have_posts()) : $latest_posts->the_post(); ?>
            <div class="col-md-4">
              <div class="blog_item">
                <!-- Featured Image -->
                <?php if (has_post_thumbnail()) : ?>
                  <img src="<?php the_post_thumbnail_url('medium'); ?>" class="card-img-top" alt="<?php the_title_attribute(); ?>">
                <?php else : ?>
                  <img src="<?php echo get_template_directory_uri(); ?>/images/shawonbinrashid-default-image-blog-thumbnail.png" class="card-img-top" alt="Default blog image">
                <?php endif; ?>
                
                <!-- Blog Content -->
                <div class="card">
                  <div class="card-body">
                    <h6>By <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a> <?php echo get_the_date('d.m.Y'); ?></h6>
                    <h5 class="card-title"><?php the_title(); ?></h5>
                    <p class="card-text"><?php echo wp_trim_words(get_the_excerpt(), 20); ?></p>
                    <a href="<?php the_permalink(); ?>" class="blog_btn">Read More<i class="fa-solid fa-angles-right"></i></a>
                  </div>
                </div>
              </div>
            </div>
          <?php endwhile;
          wp_reset_postdata(); // Always reset post data after custom queries
        else : ?>
          <p>No recent blog posts available.</p>
      <?php endif; ?>
    </div>
  </div>
</section>
<!-- blog section end -->



    <!-- Subscribe section start -->
<section id="subscribe">
    <div class="container">
        <!-- Display success or error messages here -->
        <?php if (isset($_GET['newsletter']) && $_GET['newsletter'] == 'success'): ?>
            <p class="success-message">Thank you for subscribing!</p>
        <?php elseif (isset($_GET['newsletter']) && $_GET['newsletter'] == 'error'): ?>
            <p class="error-message">There was an error. Please try again.</p>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6 order-sm-1 order-md-0">
                <div class="subscribe_item">
                    <h3>Subscribe Today <span>!</span></h3>
                    <h4>Subscribe to our newsletter and stay updated..</h4>
                </div>
            </div>
            <div class="col-md-6 order-sm-2 order-md-0">
                <div class="subscribe_form">
                    <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="POST">
                        <input type="hidden" name="action" value="subscribe_newsletter">
                        <?php wp_nonce_field('subscribe_newsletter_nonce', 'subscribe_newsletter_nonce_field'); ?>
                        <input type="email" name="email" placeholder="Enter Your Email ID" required>
                        <input type="submit" value="Send Now">
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Subscribe section end -->


    <!-- contact section start -->
    <section id="contact">
      <div class="container">
        <div class="contact_heading">
            <h3 class="title_circle"><span>Contact</span> Me!</h3>
              <h4>Keep In Touch Bro.</h4>
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="contact_items">
              <div class="contact_item">
                <img src="images/contact1.png" alt="contact img" class="img-fluid">
                <h4>Address</h4>
                <span class="address_location">Daulatpur, khulna,Bangladesh</span>
              </div>
              <div class="contact_item">
                <img src="images/contact2.png" alt="contact img" class="img-fluid">
                <h4>E-mail</h4>
                <span class="address_location">shawonbinrashid@gmail.com</span>
                <span class="address_location">crowscare936@gmail.com</span>
              </div>
              <div class="contact_item">
                <img src="images/contact3.png" alt="contact img"  class="img-fluid">
                <h4>Phone</h4>
                <span class="address_location">+8801954380698</span>
                <span class="address_location">+8801959601901</span>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="contact_from">
                <div class="topic_text">Send us a message</div>
                <p>If you have any work from me or any types of queries related to my tutorial, you can send me a message from here. It's my pleasure to help you.</p>
                <?php if (isset($_GET['contact']) && $_GET['contact'] == 'success'): ?>
                  <div class="alert alert-success" role="alert">Thank you for your message. We will get back to you soon!</div>
              <?php elseif (isset($_GET['contact']) && $_GET['contact'] == 'error'): ?>
                  <div class="alert alert-danger" role="alert">There was an error sending your message. Please try again.</div>
              <?php endif; ?>

                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="POST">
                    <input type="hidden" name="action" value="send_contact_message">
                    <?php wp_nonce_field('send_contact_message_nonce', 'send_contact_message_nonce_field'); ?>
                    <input type="text" name="name" placeholder="Enter your name" required>
                    <input type="email" name="email" placeholder="Enter your email" required>
                    <textarea name="message" cols="20" rows="10" placeholder="Your Message" required></textarea>
                    <input type="submit" class="contact_btn" value="Send Now">
                </form>
            </div>
        </div>

        
          </div>
        </div>
      </div>
    </section>
    <!-- contact section end -->
     
    <!-- back to top -->
    <div class="back2top">
      <i class="fa-solid fa-angle-up"></i>
    </div>
    <!-- back to top -->

    <!-- loader section start -->
    <!-- <div class="container-fluid px-0 mx-0">
      <div id="loadeer_container">
      </div>
    </div> -->
    <!-- loader section end -->

    <!-- theme color switcher start -->
    <div class="colord_switcher">
      <div class="theme_btn_container">
        <span class="theme_btns" data-color="#85586F" style="background:#85586F"></span>
        <span class="theme_btns" data-color="#F75023" style="background:#F75023"></span>
        <span class="theme_btns" data-color="#63BE59" style="background:#63BE59"></span>
        <span class="theme_btns" data-color="#FB2576" style="background:#FB2576"></span>
        <span class="theme_btns" data-color="#453C67" style="background:#453C67"></span>
        <span class="theme_btns" data-color="#6D67E4" style="background:#6D67E4"></span>
      </div>
      <div class="swither_button">
        <i class="fa-solid fa-gear fa-spin"></i>
      </div>
    </div>
    
    <!-- theme color switcher end -->
     
   
    <?php get_footer(); ?>