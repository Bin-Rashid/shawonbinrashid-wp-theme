<?php
/*
Template Name: Filtered Archive
*/
get_header();
?>

<div class="shawonbinrashid__filtered_archive container">
    <h1 class="shawonbinrashid__archive-title"><?php the_archive_title(); ?></h1>

    <!-- Filter Form -->
    <form method="GET" class="shawonbinrashid__archive-filter-form">
        <div class="shawonbinrashid__filter-group">
            <label for="category">Category:</label>
            <?php wp_dropdown_categories(array('show_option_all' => 'All Categories', 'name' => 'category', 'value_field' => 'slug', 'class' => 'shawonbinrashid__dropdown-category')); ?>
        </div>

        <div class="shawonbinrashid__filter-group">
            <label for="tag">Tag:</label>
            <input type="text" name="tag" placeholder="Enter tag" class="shawonbinrashid__input-tag" value="<?php echo isset($_GET['tag']) ? esc_attr($_GET['tag']) : ''; ?>">
        </div>

        <div class="shawonbinrashid__filter-group">
            <label for="author">Author:</label>
            <select name="author" class="shawonbinrashid__select-author">
                <option value="">All Authors</option>
                <?php
                $authors = get_users(array('who' => 'authors'));
                foreach ($authors as $author) {
                    $selected = (isset($_GET['author']) && $_GET['author'] == $author->ID) ? 'selected' : '';
                    echo '<option value="' . esc_attr($author->ID) . '" ' . $selected . '>' . esc_html($author->display_name) . '</option>';
                }
                ?>
            </select>
        </div>

        <div class="shawonbinrashid__filter-group">
            <label for="date">Date:</label>
            <input type="month" name="date" class="shawonbinrashid__input-date" value="<?php echo isset($_GET['date']) ? esc_attr($_GET['date']) : ''; ?>">
        </div>

        <button type="submit" class="shawonbinrashid__btn-filter">Filter <span><i class="fa-solid fa-filter"></i></span></button>
    </form>

    <!-- Posts Section -->
    <div class="shawonbinrashid__archive-posts row">
        <?php
        // Custom Query Arguments
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => 10,
            'paged' => get_query_var('paged') ? get_query_var('paged') : 1,
        );

        // Category filter
        if (!empty($_GET['category'])) {
            $args['category_name'] = sanitize_text_field($_GET['category']);
        }

        // Tag filter
        if (!empty($_GET['tag'])) {
            $args['tag'] = sanitize_text_field($_GET['tag']);
        }

        // Author filter
        if (!empty($_GET['author'])) {
            $args['author'] = absint($_GET['author']); // Ensure it's a valid author ID
        }

        // Date filter
        if (!empty($_GET['date'])) {
            $date_parts = explode('-', $_GET['date']);
            $args['date_query'] = array(
                array(
                    'year' => absint($date_parts[0]),
                    'month' => absint($date_parts[1]),
                ),
            );
        }

        // Query posts
        $query = new WP_Query($args);
        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
                ?>
                <div class="shawonbinrashid__archive-post col-md-4">
                    <div class="shawonbinrashid__card" style="background: linear-gradient(145deg, #f3f0ff, #ffffff, #e8e4ff);">
                        <div class="shawonbinrashid__card-img-top">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium', array('style' => 'width:100%;')); ?>
                            <?php else : ?>
                                <img src="<?php echo get_template_directory_uri(); ?>/images/shawonbinrashid-default-image-blog-thumbnail.png" alt="Default Thumbnail" style="width:100%;">
                            <?php endif; ?>
                        </div>
                        <div class="shawonbinrashid__card-body">
                            <h2 class="shawonbinrashid__post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                            <div class="shawonbinrashid__post-meta">
                                <span class="shawonbinrashid__post-date"><i class="fas fa-calendar-alt"></i> <?php echo get_the_date(); ?></span> |
                                <span class="shawonbinrashid__post-author"><i class="fas fa-user"></i> <?php the_author(); ?></span>
                            </div>
                            <p class="shawonbinrashid__post-excerpt"><?php the_excerpt(); ?></p>
                            <a href="<?php the_permalink(); ?>" class="shawonbinrashid__read-more">Read More</a>
                        </div>
                    </div>
                </div>
                <?php
            endwhile;
        else :
            echo '<p class="shawonbinrashid__no-posts">No posts found matching your criteria.</p>';
        endif;
        wp_reset_postdata();
        ?>
    </div>

    <!-- Pagination -->
    <div class="shawonbinrashid__pagination">
        <?php
        echo paginate_links(array(
            'total' => $query->max_num_pages,
        ));
        ?>
    </div>
</div>

<?php get_footer(); ?>
