<?php
/*
Template Name: Multi-Column Category Layout
*/
get_header();
?>

<div class="shawonbinrashid__category-archive container">
    <header class="shawonbinrashid__category-header">
        <h1 class="shawonbinrashid__category-title"><?php single_cat_title(); ?> Posts</h1>
        <p class="shawonbinrashid__category-description"><?php echo category_description(); ?></p>
    </header>

    <div class="shawonbinrashid__category-layout">
        <?php
        // Get categories to display each in a grid layout
        $categories = get_categories();
        foreach ($categories as $category) :
            $args = array(
                'cat' => $category->term_id,
                'posts_per_page' => 6,
            );
            $query = new WP_Query($args);
            if ($query->have_posts()) :
        ?>
            <section class="shawonbinrashid__category-section">
                <h2 class="shawonbinrashid__category-section-title"><?php echo esc_html($category->name); ?></h2>
                <div class="shawonbinrashid__category-grid">
                    <?php while ($query->have_posts()) : $query->the_post(); ?>
                        <article class="shawonbinrashid__category-post">
                            <a href="<?php the_permalink(); ?>" class="shawonbinrashid__category-post-link">
                                <?php if (has_post_thumbnail()) : ?>
                                    <div class="shawonbinrashid__category-post-img">
                                        <?php the_post_thumbnail('medium'); ?>
                                    </div>
                                <?php else : ?>
                                    <div class="shawonbinrashid__category-post-img">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/default-thumbnail.jpg" alt="Default Thumbnail">
                                    </div>
                                <?php endif; ?>
                                <div class="shawonbinrashid__category-post-content">
                                    <h3 class="shawonbinrashid__category-post-title"><?php the_title(); ?></h3>
                                    <p class="shawonbinrashid__category-post-excerpt"><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                                </div>
                            </a>
                        </article>
                    <?php endwhile; ?>
                </div>
                <a href="<?php echo get_category_link($category->term_id); ?>" class="shawonbinrashid__category-more">View More &raquo;</a>
            </section>
        <?php
            endif;
            wp_reset_postdata();
        endforeach;
        ?>
    </div>
</div>

<?php get_footer(); ?>