<?php
/**
 * Template Name: Custom Post Author
 * Description: A template to display each author's latest post.
 */
get_header();
?>

<div class="shawonbinrashid__author_letest_post container">
    <div class="row">
        <?php
        $authors = get_users(['capability' => 'publish_posts']);
        foreach ($authors as $author) {
            // Get the author's latest post
            $latest_post = get_posts([
                'author' => $author->ID,
                'numberposts' => 1,
            ]);

            if (!empty($latest_post)) {
                $post = $latest_post[0];
                setup_postdata($post);
        ?>
                <div class="col-md-4">
                    <div class="card" style="border: 1px dashed #6C71FE; border-radius: 16px;">
                        <?php if (has_post_thumbnail($post->ID)) : ?>
                        <div class="card-thumbnail">
                            <?php echo get_the_post_thumbnail($post->ID, 'medium'); ?>
                        </div>
                        <?php endif; ?>

                        <div class="card-body">
                            <div class="author-info" style="display: flex; align-items: center;">
                                <?php echo get_avatar($author->ID, 60, '', '', ['class' => 'rounded-circle']); ?>
                                <div style="margin-left: 10px;">
                                    <h6><?php echo esc_html($author->display_name); ?></h6>
                                    <?php
                                    // Retrieve the author's designation/title meta (or any custom field key you've used)
                                    $designation = get_user_meta($author->ID, 'designation', true);
                                    if ($designation) {
                                        echo '<p class="author-title">' . esc_html($designation) . '</p>';
                                    } else {
                                        echo '<p class="author-title">No Title Available</p>';
                                    }
                                    ?>
                                </div>
                            </div>

                            <h5 class="post-title"><a href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                                    <?php echo esc_html(get_the_title($post->ID)); ?></a></h5>
                            <p class="post-excerpt"><?php echo wp_trim_words(get_the_excerpt($post->ID), 20); ?></p>

                            <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="read-more-btn">
                                <span>Read More</span> <i class="icon-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
        <?php
                wp_reset_postdata();
            }
        }
        ?>
    </div>
</div>

<?php get_footer(); ?>
