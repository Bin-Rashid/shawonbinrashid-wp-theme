<?php
require_once get_template_directory() . '/lib/attachment.php';


function shawonbinrashid_bootstraping() {
    // Load theme's text domain for translation
    load_theme_textdomain('shawonbinrashid', get_template_directory() . '/languages');

    // Add support for document title tag managed by WordPress
    add_theme_support('title-tag');

    // Add support for post thumbnails (featured images)
    add_theme_support('post-thumbnails');
    
    // Add custom image size (if needed)
    // add_image_size('shawonbinrashid-custom-size', 800, 600, true);

    // Register navigation menus (where to add your menu locations)
    register_nav_menus(array(
        'primary_menu' => __('Primary Menu', 'shawonbinrashid')
    ));

    // Add HTML5 support for certain elements
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));

    // Add support for custom logo (use custom height and width as needed)
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // Add support for custom background
    add_theme_support('custom-background', array(
        'default-color' => '#ffffff', // Add your background color here
        'default-image' => '', // Add your background image here if needed
    ));

    // Add support for selective refresh widgets in the customizer
    add_theme_support('customize-selective-refresh-widgets');

    // Add support for WooCommerce if needed
    // add_theme_support('woocommerce');

    // Add support for block editor styles if using Gutenberg
    add_theme_support('editor-styles');
    // Enqueue editor styles for Gutenberg
    add_editor_style('css/editor-style.css');

    // Enable wide and full block alignments for block editor (Gutenberg)
    add_theme_support('align-wide');

    // Enable custom color palette for block editor
    add_theme_support('editor-color-palette', array(
        array(
            'name'  => __('Primary Color', 'shawonbinrashid'),
            'slug'  => 'primary',
            'color' => '#0073aa',
        ),
        array(
            'name'  => __('Secondary Color', 'shawonbinrashid'),
            'slug'  => 'secondary',
            'color' => '#222',
        ),
        // Add more custom colors here
    ));
}

add_action('after_setup_theme', 'shawonbinrashid_bootstraping');




function enqueue_shawonbinrashid_assets() {
    // Enqueue google font styles
    wp_enqueue_style('shawonbinrashid-google-font', '//fonts.googleapis.com/css2?family=Covered+By+Your+Grace&family=Raleway:wght@400;500;600;700;800&display=swap', array(), null);
    // Enqueue CSS files
    wp_enqueue_style('venobox-css', get_theme_file_uri('css/venobox.min.css'), array(), time());
    wp_enqueue_style('wow-css', get_theme_file_uri('css/animate.min.css'), array(), time());
    wp_enqueue_style('slick-css', get_theme_file_uri('css/slick.css'), array(), time());
    wp_enqueue_style('slick-theme-css', get_theme_file_uri('css/slick-theme.css'), array(), time());
    wp_enqueue_style('rprogressbar-css', get_theme_file_uri('css/jquery.rprogessbar.min.css'), array(), time());
    wp_enqueue_style('simple-lightbox-css', get_theme_file_uri('css/simple-lightbox.min.css'), array(), time());
    wp_enqueue_style('fontawesome-all-css', get_theme_file_uri('css/all.min.css'), array(), time());
    wp_enqueue_style('fontawesome-css', get_theme_file_uri('css/fontawesome.min.css'), array(), time());
    wp_enqueue_style('bootstrap-css', get_theme_file_uri('css/bootstrap.min.css'), array(), time());
    wp_enqueue_style('style-css', get_theme_file_uri('css/style.css'), array(), time());
    wp_enqueue_style('responsive-css', get_theme_file_uri('css/responcive.css'), array(), time());
    // tiny slider css
    wp_enqueue_style('tns-slider-css', '//cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.4/tiny-slider.css');
    wp_enqueue_style('shawonbinrashid-theme-stylesheet', get_stylesheet_uri(),null,time());

    // Enqueue JS files
    wp_enqueue_script('bootstrap-js', get_theme_file_uri('js/bootstrap.min.js'), array('jquery'), time(), true);
    wp_enqueue_script('typed-js', get_theme_file_uri('js/typed.min.js'), array('jquery'), time(), true);
    wp_enqueue_script('venobox-js', get_theme_file_uri('js/venobox.min.js'), array('jquery'), time(), true);
    wp_enqueue_script('parallax-js', get_theme_file_uri('js/parallax.min.js'), array('jquery'), time(), true);
    wp_enqueue_script('rprogressbar-js', get_theme_file_uri('js/jQuery.rProgressbar.min.js'), array('jquery'), time(), true);
    wp_enqueue_script('simple-lightbox-js', get_theme_file_uri('js/simple-lightbox.min.js'), array('jquery'), time(), true);
    wp_enqueue_script('slick-js', get_theme_file_uri('js/slick.min.js'), array('jquery'), time(), true);
    wp_enqueue_script('waypoints-js', get_theme_file_uri('js/waypoints.min.js'), array('jquery'), time(), true);
    wp_enqueue_script('counterup-js', get_theme_file_uri('js/jquery.counterup.min.js'), array('jquery'), time(), true);
    wp_enqueue_script('all-js', get_theme_file_uri('js/all.min.js'), array('jquery'), time(), true);
    // Enqueue Featherlight JS for lightbox functionality, with jQuery as a dependency
    wp_enqueue_script('tns-js', '//cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.2/min/tiny-slider.js', array('jquery'), time(), true);
    wp_enqueue_script('custom-js', get_theme_file_uri('js/custom.js'), array('jquery'), time(), true);

    // Get typed text strings from the Customizer setting
    $typed_strings = get_theme_mod('typed_text_strings', 'A Frontend Designer, A Web Developer');
    $typed_strings_array = explode(',', $typed_strings); // Split the comma-separated strings

    // Pass typed strings to JavaScript
    wp_add_inline_script('typed-js', 'var typedOptions = ' . json_encode($typed_strings_array) . ';', 'before');

    // Initialize Typed.js with dynamic options
    wp_add_inline_script('typed-js', '
        document.addEventListener("DOMContentLoaded", function() {
            new Typed(".type", {
                strings: typedOptions,
                smartBackspace: true,
                typeSpeed: 70,
                startDelay: 50,
                loop: true,
                backDelay: 1000
            });
        });
    ');

    
}

add_action('wp_enqueue_scripts', 'enqueue_shawonbinrashid_assets');

// custom things
function shawonbinrashid_customize_register($wp_customize) {
    // Add Section for Hero Image
    $wp_customize->add_section('hero_section', array(
        'title'    => __('Hero Section', 'shawonbinrashid'),
        'priority' => 30,
    ));

    // Add Setting for Hero Image
    $wp_customize->add_setting('hero_image', array(
        'default'   => '',
        'transport' => 'refresh',
    ));

    // Add Control for Hero Image
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'hero_image', array(
        'label'    => __('Upload Hero Image', 'shawonbinrashid'),
        'section'  => 'hero_section',
        'settings' => 'hero_image',
    )));

    // Add Section for About Image
    $wp_customize->add_section('about__section', array(
        'title'    => __('About Section', 'shawonbinrashid'),
        'priority' => 40,
    ));
    // Add Setting for About Image
    $wp_customize->add_setting('about__image', array(
        'default'   => '',
        'transport' => 'refresh',
    ));

    // Add Control for About Image
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'about__image', array(
        'label'    => __('Upload Hero Image', 'shawonbinrashid'),
        'section'  => 'about__section',
        'settings' => 'about__image',
    )));


    // Social Media Section
    $wp_customize->add_section('shawonbinrashid_social_media_section', array(
        'title'    => __('Social Media', 'shawonbinrashid'),
        'priority' => 50,
    ));

    // Define a setting to hold social media items
    $wp_customize->add_setting('shawonbinrashid_social_media', array(
        'default'           => json_encode(array()),
        'sanitize_callback' => 'shawonbinrashid_sanitize_social_media',
    ));

    // Add a control for social media links
    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'shawonbinrashid_social_media_control',
        array(
            'label'    => __('Social Media Links', 'shawonbinrashid'),
            'section'  => 'shawonbinrashid_social_media_section',
            'settings' => 'shawonbinrashid_social_media',
            'type'     => 'textarea',
            'description' => __('Enter each social media link as JSON. Example: [{"icon":"facebook-f","url":"https://facebook.com"}, {"icon":"twitter","url":"https://twitter.com"}]', 'shawonbinrashid'),
        )
    ));

    // Add a new section in the Customizer for Typed.js settings
    $wp_customize->add_section('typed_text_section', array(
        'title'    => __('Hero Area Author Info', 'yourtheme'),
        'priority' => 60,
    ));

    // Add a setting for the typed text strings
    $wp_customize->add_setting('typed_text_strings', array(
        'default'   => 'A Frontend Designer, A Web Developer',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    // Add a control to input the typed text strings
    $wp_customize->add_control('typed_text_strings', array(
        'label'    => __('Typed Text (separate with commas)', 'yourtheme'),
        'section'  => 'typed_text_section',
        'type'     => 'textarea',
    ));
    // Add settings for the person's name
    $wp_customize->add_setting('person_first_name', array(
        'default'           => 'Shawon',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    $wp_customize->add_setting('person_last_name', array(
        'default'           => 'Ahmed',
        'sanitize_callback' => 'sanitize_text_field',
    ));

    // Add a setting for the person's description
    $wp_customize->add_setting('person_description', array(
        'default'           => 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sit ea, sint veritatis est ullam debitis harum. Minima laborum, nam tenetur amet ad error ipsam laboriosam!',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));

    // Add controls for the person's name and description
    $wp_customize->add_control('person_first_name', array(
        'label'    => __('First Name', 'yourtheme'),
        'section'  => 'typed_text_section',
        'type'     => 'text',
    ));

    $wp_customize->add_control('person_last_name', array(
        'label'    => __('Last Name', 'yourtheme'),
        'section'  => 'typed_text_section',
        'type'     => 'text',
    ));

    $wp_customize->add_control('person_description', array(
        'label'    => __('Description', 'yourtheme'),
        'section'  => 'typed_text_section',
        'type'     => 'textarea',
    ));

    // Add a section for the logo settings
    $wp_customize->add_section('logo_section', array(
        'title'    => __('Logo Settings', 'yourtheme'),
        'priority' => 25,
    ));

    // Logo type: Text or Image
    $wp_customize->add_setting('logo_type', array(
        'default'           => 'text',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('logo_type', array(
        'label'    => __('Select Logo Type', 'yourtheme'),
        'section'  => 'logo_section',
        'type'     => 'radio',
        'choices'  => array(
            'text'  => __('Text Logo', 'yourtheme'),
            'image' => __('Image Logo', 'yourtheme'),
        ),
    ));

    // Text logo first part (e.g., "Shawon")
    $wp_customize->add_setting('text_logo_first_part', array(
        'default'           => 'Shawon',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('text_logo_first_part', array(
        'label'    => __('Text Logo First Part', 'yourtheme'),
        'section'  => 'logo_section',
        'type'     => 'text',
    ));

    // Text logo second part (e.g., "Ahmed")
    $wp_customize->add_setting('text_logo_second_part', array(
        'default'           => 'Ahmed',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('text_logo_second_part', array(
        'label'    => __('Text Logo Second Part', 'yourtheme'),
        'section'  => 'logo_section',
        'type'     => 'text',
    ));

    // Image logo upload
    $wp_customize->add_setting('image_logo', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'image_logo', array(
        'label'    => __('Upload Logo Image', 'yourtheme'),
        'section'  => 'logo_section',
        'settings' => 'image_logo',
    )));

    // Footer Logo Section
    $wp_customize->add_section('footer_logo_section', array(
        'title' => __('Footer Logo', 'yourtheme'),
        'priority' => 30,
    ));

    // Logo Type (Image/Text)
    $wp_customize->add_setting('footer_logo_type', array('default' => 'text'));
    $wp_customize->add_control('footer_logo_type', array(
        'label' => __('Logo Type', 'yourtheme'),
        'section' => 'footer_logo_section',
        'type' => 'radio',
        'choices' => array(
            'text' => 'Text',
            'image' => 'Image'
        ),
    ));

    // Text Logo Fields (Two Parts)
    $wp_customize->add_setting('footer_logo_text_part1', array('default' => 'Shawon'));
    $wp_customize->add_control('footer_logo_text_part1', array(
        'label' => __('Logo Text Part 1', 'yourtheme'),
        'section' => 'footer_logo_section',
        'type' => 'text',
    ));

    $wp_customize->add_setting('footer_logo_text_part2', array('default' => 'Ahmed'));
    $wp_customize->add_control('footer_logo_text_part2', array(
        'label' => __('Logo Text Part 2', 'yourtheme'),
        'section' => 'footer_logo_section',
        'type' => 'text',
    ));

    // Image Logo Upload
    $wp_customize->add_setting('footer_logo_image');
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'footer_logo_image', array(
        'label' => __('Footer Logo Image', 'yourtheme'),
        'section' => 'footer_logo_section',
        'settings' => 'footer_logo_image',
    )));

    // Social Links JSON
    $wp_customize->add_section('footer_social_section', array(
        'title' => __('Footer Social Links', 'yourtheme'),
        'priority' => 31,
    ));
    $wp_customize->add_setting('footer_social_links', array('default' => '[{"icon": "fa-facebook-f", "url": "#"}, {"icon": "fa-twitter", "url": "#"}]'));
    $wp_customize->add_control('footer_social_links', array(
        'label' => __('Social Links JSON', 'yourtheme'),
        'section' => 'footer_social_section',
        'type' => 'textarea',
        'description' => __('Enter a JSON array with objects containing "icon" (FontAwesome class) and "url".'),
    ));

    // Copyright Text
    $wp_customize->add_section('footer_copyright_section', array(
        'title' => __('Footer Copyright', 'yourtheme'),
        'priority' => 32,
    ));
    $wp_customize->add_setting('footer_copyright_text', array('default' => '© 2024 Shawon Ahmed. All Rights Reserved'));
    $wp_customize->add_control('footer_copyright_text', array(
        'label' => __('Copyright Text', 'yourtheme'),
        'section' => 'footer_copyright_section',
        'type' => 'text',
    ));

    // services area customizer
    $wp_customize->add_panel('services_panel', array(
        'title'       => __('Services Section', 'shawonbinrashid'),
        'priority'    => 30,
    ));

    // Loop to add settings for each service
    for ($i = 1; $i <= 6; $i++) { // 6 services in the section
        $wp_customize->add_section("service_section_$i", array(
            'title'    => __("Service $i", 'shawonbinrashid'),
            'panel'    => 'services_panel',
        ));

        // Service Icon
        $wp_customize->add_setting("service_icon_$i", array(
            'default'   => '',
            'sanitize_callback' => 'esc_url',
        ));
        $wp_customize->add_control(new WP_Customize_Image_Control(
            $wp_customize, "service_icon_$i", array(
                'label'    => __("Service Icon $i", 'shawonbinrashid'),
                'section'  => "service_section_$i",
                'settings' => "service_icon_$i",
            )
        ));

        // Service Title
        $wp_customize->add_setting("service_title_$i", array(
            'default'   => __("Service Title $i", 'shawonbinrashid'),
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control("service_title_$i", array(
            'label'    => __("Service Title $i", 'shawonbinrashid'),
            'section'  => "service_section_$i",
            'type'     => 'text',
        ));

        // Service Description
        $wp_customize->add_setting("service_description_$i", array(
            'default'   => __("Service description goes here.", 'shawonbinrashid'),
            'sanitize_callback' => 'sanitize_textarea_field',
        ));
        $wp_customize->add_control("service_description_$i", array(
            'label'    => __("Service Description $i", 'shawonbinrashid'),
            'section'  => "service_section_$i",
            'type'     => 'textarea',
        ));
    }

    // Add a panel for the Projects Section
    $wp_customize->add_panel('projects_panel', array(
        'title'       => __('Projects Section', 'your_theme_textdomain'),
        'priority'    => 31,
    ));

    // Loop to add settings for each project metric
    $metrics = array(
        'projects_completed' => 'Project completed',
        'happy_clients'      => 'Happy Client',
        'cups_of_coffee'     => 'Cup Of Coffee',
        'total_awards'       => 'Total Awards'
    );

    foreach ($metrics as $key => $label) {
        $wp_customize->add_section("project_section_$key", array(
            'title'    => __("$label", 'your_theme_textdomain'),
            'panel'    => 'projects_panel',
        ));

        // Project Icon
        $wp_customize->add_setting("{$key}_icon", array(
            'default'   => '',
            'sanitize_callback' => 'esc_url',
        ));
        $wp_customize->add_control(new WP_Customize_Image_Control(
            $wp_customize, "{$key}_icon", array(
                'label'    => __("{$label} Icon", 'your_theme_textdomain'),
                'section'  => "project_section_$key",
                'settings' => "{$key}_icon",
            )
        ));

        // Project Count
        $wp_customize->add_setting("{$key}_count", array(
            'default'   => 0,
            'sanitize_callback' => 'absint',
        ));
        $wp_customize->add_control("{$key}_count", array(
            'label'    => __("{$label} Count", 'your_theme_textdomain'),
            'section'  => "project_section_$key",
            'type'     => 'number',
        ));

        // Portfolio section
        $wp_customize->add_panel('portfolio_panel', array(
            'title'       => __('Portfolio Section', 'your_theme_textdomain'),
            'priority'    => 31,
        ));
    
        // Loop to add settings for each portfolio item
        for ($i = 1; $i <= 6; $i++) { // Adjust this number to the number of portfolio items you want
            $wp_customize->add_section("portfolio_section_$i", array(
                'title'    => __("Portfolio Item $i", 'your_theme_textdomain'),
                'panel'    => 'portfolio_panel',
            ));
    
            // Portfolio Image
            $wp_customize->add_setting("portfolio_image_$i", array(
                'default'   => '',
                'sanitize_callback' => 'esc_url',
            ));
            $wp_customize->add_control(new WP_Customize_Image_Control(
                $wp_customize, "portfolio_image_$i", array(
                    'label'    => __("Portfolio Image $i", 'your_theme_textdomain'),
                    'section'  => "portfolio_section_$i",
                    'settings' => "portfolio_image_$i",
                )
            ));
        }
    }
    // ===============Skill progressbar ====================//
    $wp_customize->add_panel('skills_panel', array(
        'title'       => __('Skills Section', 'your_theme_textdomain'),
        'priority'    => 32,
    ));

    // Loop to add settings for each skill item
    for ($i = 1; $i <= 6; $i++) { // Adjust this number based on the number of skills you want
        $wp_customize->add_section("skill_section_$i", array(
            'title'    => __("Skill Item $i", 'your_theme_textdomain'),
            'panel'    => 'skills_panel',
        ));

        // Skill Image
        $wp_customize->add_setting("skill_image_$i", array(
            'default'   => '',
            'sanitize_callback' => 'esc_url',
        ));
        $wp_customize->add_control(new WP_Customize_Image_Control(
            $wp_customize, "skill_image_$i", array(
                'label'    => __("Skill Image $i", 'your_theme_textdomain'),
                'section'  => "skill_section_$i",
                'settings' => "skill_image_$i",
            )
        ));

        // Skill Title
        $wp_customize->add_setting("skill_title_$i", array(
            'default'   => '',
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control("skill_title_$i", array(
            'label'    => __("Skill Title $i", 'your_theme_textdomain'),
            'section'  => "skill_section_$i",
            'type'     => 'text',
        ));

        // Skill Percentage
        $wp_customize->add_setting("skill_percentage_$i", array(
            'default'   => 0,
            'sanitize_callback' => 'absint',
        ));
        $wp_customize->add_control("skill_percentage_$i", array(
            'label'    => __("Skill Percentage $i", 'your_theme_textdomain'),
            'section'  => "skill_section_$i",
            'type'     => 'number',
            'input_attrs' => array(
                'min' => 0,
                'max' => 100,
            ),
        ));
    }

    
}
add_action('customize_register', 'shawonbinrashid_customize_register');

// Sanitize JSON input
function shawonbinrashid_sanitize_social_media($input) {
    $decoded = json_decode($input, true);
    return is_array($decoded) ? $input : json_encode(array());
}

// about section about detail icon and text
function about_section_meta_box() {
    add_meta_box(
        'about_section',
        'About Section Data',
        'render_about_section_meta_box',
        'page', // Add it to a specific post type, like 'page'
        'normal',
        'default'
    );
}
add_action('add_meta_boxes', 'about_section_meta_box');

function render_about_section_meta_box($post) {
    $about_section_data = get_post_meta($post->ID, '_about_section_data', true);
    ?>
    <label for="about_section_data">Enter About Section Data (JSON format):</label>
    <textarea name="about_section_data" id="about_section_data" rows="10" style="width: 100%;"><?php echo esc_textarea($about_section_data); ?></textarea>
    <p>Example JSON format:</p>
    <pre>[{"icon": "fa-user", "label": "Name", "value": "Shawon"}, {"icon": "fa-cake-candles", "label": "Age", "value": "21"}]</pre>
    <?php
}

function save_about_section_meta_box($post_id) {
    if (array_key_exists('about_section_data', $_POST)) {
        update_post_meta(
            $post_id,
            '_about_section_data',
            sanitize_textarea_field($_POST['about_section_data'])
        );
    }
}
add_action('save_post', 'save_about_section_meta_box');
// ==================end==================//

// testemonial section




function my_theme_widgets_init() {
    register_sidebar( array(
        'name'          => 'Sidebar',
        'id'            => 'sidebar-1',
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5 class="widget-title">',
        'after_title'   => '</h5>',
    ) );
}
add_action( 'widgets_init', 'my_theme_widgets_init' );

// custom excerpt length
function custom_excerpt_length($length) {
    return 30; // Set this to your desired word count
}

function new_excerpt_more($more) {
    return ''; // Remove the [...] more text
}

add_filter('excerpt_length', 'custom_excerpt_length');
add_filter('excerpt_more', 'new_excerpt_more');


class WP_Bootstrap_Navwalker extends Walker_Nav_Menu {
    function start_lvl(&$output, $depth = 0, $args = null) {
        // Different classes for each level of depth
        $classes = ($depth == 0) ? 'dropdown-menu' : 'dropdown-menu-nested';
        $output .= "\n<ul class='{$classes}'>\n";
    }

    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'nav-item';
        
        // Add dropdown classes based on depth
        if ($args->walker->has_children) {
            $classes[] = ($depth == 0) ? 'dropdown' : 'dropdown dropdown-item';
        }

        // Build class attribute
        $class_names = join(' ', array_filter($classes));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';

        // Start list item
        $output .= "<li$class_names>";

        // Set link attributes
        $atts = array();
        $atts['class'] = ($depth == 0) ? 'nav-link' : 'dropdown-item dropdown-link-nested';
        $atts['href'] = !empty($item->url) ? $item->url : '';

        // Add caret for first level dropdown items
        if ($args->walker->has_children && $depth == 0) {
            $atts['class'] .= ' dropdown-toggle';
            $atts['data-bs-toggle'] = 'dropdown';
            $atts['aria-expanded'] = 'false';
        }

        // Build attributes string
        $attributes = '';
        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $value = esc_attr($value);
                $attributes .= " $attr='$value'";
            }
        }

        // Output link element
        $output .= "<a$attributes>";
        $output .= apply_filters('the_title', $item->title, $item->ID);
        $output .= "</a>";
    }
}

// Function to calculate reading time
function get_reading_time() {
    $content = get_post_field('post_content', get_the_ID());
    $word_count = str_word_count(strip_tags($content));
    $reading_time = ceil($word_count / 200); // Average reading speed is about 200 words per minute
    return $reading_time . ' min read';
}
function custom_comment_callback( $comment, $args, $depth ) {
    $GLOBALS['comment'] = $comment; ?>
    <li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
        <div class="comment-body" style="background-color: #F6EFBD; border: 1px solid #BC7C7C; padding: 15px; border-radius: 10px; margin-bottom: 15px;">
            <div class="comment-author-avatar">
                <?php echo get_avatar( $comment, 60 ); ?>
            </div>
            <div class="comment-content" style="margin-left: 70px;">
                <div class="comment-meta">
                    <span class="comment-author-name" style="font-weight: bold;"><?php echo get_comment_author_link(); ?></span>
                    <span class="comment-date"><?php printf( esc_html__( '%1$s at %2$s', 'your-text-domain' ), get_comment_date(), get_comment_time() ); ?></span>
                </div>
                <div class="comment-text">
                    <?php comment_text(); ?>
                </div>
                <div class="comment-actions" style="margin-top: 10px;">
                    <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => 'Reply' ) ) ); ?>
                    <a href="#" class="edit-comment" data-comment-id="<?php comment_ID(); ?>">Edit</a>
                </div>
            </div>
        </div>
    </li>
<?php
}



function handle_update_comment() {
    if (isset($_POST['comment_id']) && isset($_POST['comment_content'])) {
        $comment_id = intval($_POST['comment_id']);
        $comment_content = sanitize_text_field($_POST['comment_content']);

        $update_result = wp_update_comment(array(
            'comment_ID' => $comment_id,
            'comment_content' => $comment_content
        ));

        if ($update_result) {
            wp_send_json_success();
        } else {
            wp_send_json_error();
        }
    }
    wp_die();
}
add_action('wp_ajax_update_comment', 'handle_update_comment');
add_action('wp_ajax_nopriv_update_comment', 'handle_update_comment');



class Custom_Calendar_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'custom_calendar_widget',
            __('Custom Calendar Widget', 'text_domain'),
            array('description' => __('A Custom Calendar Widget with Navigation', 'text_domain'))
        );
    }

    public function widget($args, $instance) {
        echo $args['before_widget'];

        // Display the calendar
        echo '<div id="wp-calendar" class="wp-calendar-table">';
        echo '<caption>' . esc_html(date('F Y')) . '</caption>';
        echo '<thead>';
        echo '<tr>';
        echo '<th scope="col" title="Monday">M</th>';
        echo '<th scope="col" title="Tuesday">T</th>';
        echo '<th scope="col" title="Wednesday">W</th>';
        echo '<th scope="col" title="Thursday">T</th>';
        echo '<th scope="col" title="Friday">F</th>';
        echo '<th scope="col" title="Saturday">S</th>';
        echo '<th scope="col" title="Sunday">S</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        // Your calendar body generation here, e.g., using a loop to populate days
        echo '</tbody>';
        echo '</div>';

        // Add navigation buttons
        echo '<nav aria-label="Previous and next months" class="wp-calendar-nav">';
        echo '<div class="calendar-nav">';
        echo '<span class="wp-calendar-nav-prev"><a href="#" class="calendar-button">« Previous Month</a></span>';
        echo '<span class="wp-calendar-nav-next"><a href="#" class="calendar-button">Next Month »</a></span>';
        echo '</div>';
        echo '</nav>';

        echo $args['after_widget'];
    }

    public function form($instance) {
        // Form for widget settings, if any
    }

    public function update($new_instance, $old_instance) {
        // Update widget settings, if any
    }
}

function register_custom_calendar_widget() {
    register_widget('Custom_Calendar_Widget');
}

add_action('widgets_init', 'register_custom_calendar_widget');

// ================ News Letter =============//
function create_newsletter_post_type() {
    register_post_type('newsletter', array(
        'labels' => array(
            'name' => __('Newsletter Inbox'),
            'singular_name' => __('Subscriber'),
        ),
        'public' => false,
        'has_archive' => false,
        'menu_position' => 20,
        'show_ui' => true,
        'supports' => array('title'),
        'capability_type' => 'post',
        'menu_icon' => 'dashicons-cloud-saved', // Using a WordPress Dashicon
    ));
}
add_action('init', 'create_newsletter_post_type');

function handle_newsletter_submission() {
    if (!isset($_POST['subscribe_newsletter_nonce_field']) ||
        !wp_verify_nonce($_POST['subscribe_newsletter_nonce_field'], 'subscribe_newsletter_nonce')) {
        wp_die('Nonce verification failed');
    }

    if (isset($_POST['email']) && is_email($_POST['email'])) {
        $email = sanitize_email($_POST['email']);
        // Create a new post of type 'newsletter'
        $post_id = wp_insert_post(array(
            'post_type' => 'newsletter',
            'post_title' => $email,
            'post_status' => 'publish',
        ));

        if ($post_id) {
            wp_redirect(home_url('/?newsletter=success'));
            exit;
        }
    }
    wp_redirect(home_url('/?newsletter=error'));
    exit;
}
add_action('admin_post_nopriv_subscribe_newsletter', 'handle_newsletter_submission');
add_action('admin_post_subscribe_newsletter', 'handle_newsletter_submission');

function newsletter_custom_columns($columns) {
    $columns['email'] = 'Email';
    unset($columns['date']);
    return $columns;
}

function newsletter_custom_columns_data($column, $post_id) {
    if ($column == 'email') {
        echo get_the_title($post_id);
    }
}

add_filter('manage_newsletter_posts_columns', 'newsletter_custom_columns');
add_action('manage_newsletter_posts_custom_column', 'newsletter_custom_columns_data', 10, 2);


// Contact Form
function handle_contact_form_submission() {
    // Verify nonce
    if (!isset($_POST['send_contact_message_nonce_field']) ||
        !wp_verify_nonce($_POST['send_contact_message_nonce_field'], 'send_contact_message_nonce')) {
        wp_die('Nonce verification failed');
    }

    // Sanitize and validate input data
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $message = sanitize_textarea_field($_POST['message']);

    if (!is_email($email)) {
        wp_redirect(home_url('/?contact=error'));
        exit;
    }

    // Create a new post of type 'contact_message'
    $post_id = wp_insert_post(array(
        'post_type'   => 'contact_message',
        'post_title'  => $name . ' - ' . $email,
        'post_content' => $message,
        'post_status' => 'publish',
    ));

    // Send an email notification (optional)
    if ($post_id) {
        $to = get_option('admin_email');
        $subject = 'New Contact Message from ' . $name;
        $body = 'You have received a new message from ' . $name . " (" . $email . "):\n\n" . $message;
        $headers = array('Content-Type: text/plain; charset=UTF-8');
        wp_mail($to, $subject, $body, $headers);

        // Redirect with success message
        wp_redirect(home_url('/?contact=success'));
        exit;
    }

    // Redirect with error message if saving failed
    wp_redirect(home_url('/?contact=error'));
    exit;
}
add_action('admin_post_nopriv_send_contact_message', 'handle_contact_form_submission');
add_action('admin_post_send_contact_message', 'handle_contact_form_submission');
function create_contact_message_post_type() {
    register_post_type('contact_message', array(
        'labels' => array(
            'name' => __('Contact Inbox'),
            'singular_name' => __('Contact Message'),
        ),
        'public' => false,
        'has_archive' => false,
        'menu_position' => 20,
        'show_ui' => true,
        'supports' => array('title', 'editor'),
        'capability_type' => 'post',
        'menu_icon' => 'dashicons-email', // Using a WordPress Dashicon
    ));
}
add_action('init', 'create_contact_message_post_type');



// user registration
function add_author_designation_field($user_id) {
    if (!get_user_meta($user_id, 'designation', true)) {
        update_user_meta($user_id, 'designation', 'Your Title Here'); // Default value if empty
    }
}
add_action('user_register', 'add_author_designation_field'); // Add on registration

// For existing users, you can manually call this function in a loop or through the admin panel
// Add the Designation field to the user profile page
function add_designation_field($user) {
    ?>
    <h3>Additional Profile Information</h3>
    <table class="form-table">
        <tr>
            <th><label for="designation">Designation</label></th>
            <td>
                <input type="text" name="designation" id="designation" value="<?php echo esc_attr(get_the_author_meta('designation', $user->ID)); ?>" class="regular-text" />
                <p class="description">Please enter the user's designation.</p>
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'add_designation_field');
add_action('edit_user_profile', 'add_designation_field');
// Save the Designation field
function save_designation_field($user_id) {
    // Check if current user can edit the user profile
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }

    // Update user meta with the Designation value
    update_user_meta($user_id, 'designation', sanitize_text_field($_POST['designation']));
}
add_action('personal_options_update', 'save_designation_field');
add_action('edit_user_profile_update', 'save_designation_field');

