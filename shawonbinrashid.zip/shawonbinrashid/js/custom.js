;(function($){
  'use strict';

  // counterUp js
    $('.counter').counterUp({
        delay: 30,
        time: 3000
    });



    // progressbar js
    $('.progress-bar').each(function() {
      var percentage = $(this).data('percentage');
      $(this).rProgressbar({
          percentage: percentage,
          fillBackgroundColor:'#420808',
          backgroundColor:'#666666',
          borderRadius:'0px',
          height:'10px',
          width:'80%',
          duration: 2000,
      });
  });
  

  // fixed navbar js
  var navbar = $('.navbar');
  $(window).on('scroll',function(){
        
    var scrolling = $(this).scrollTop();
    
    if(scrolling > 200){
        navbar.addClass("bg");
       }
    else{
        navbar.removeClass('bg');
    }
});

// As A Vanilla JavaScript Plugin
var gallery =new SimpleLightbox('#portfolio .container .gallary_img a img', {


});


    

  // slick slider
//   $('.testimonials_item').slick({
//     slidesToShow: 1,
//     slidesToScroll: 1,
//     autoplay: true,
//     autoplaySpeed: 2500,
//     dots: true,
//     prevArrow: '<span class="prev_arrow"><i class="fa-regular fa-square-caret-left"></i></span>',
//     nextArrow: '<span class="next_arrow"><i class="fa-regular fa-square-caret-right"></i></span>',
// });


  // loader js
  $(window).on("load",function(){
    $("#loadeer_container").fadeOut(2500);

  });

  
// Toggle the color switcher panel
$('.swither_button').click(function(){
  $('.colord_switcher').toggleClass('color_togoller');
});

// Set up the color buttons
let themeBtn = document.querySelectorAll('.theme_btns');

themeBtn.forEach(color => {
  color.addEventListener('click', () => {
    let dataColor = color.getAttribute('data-color');
    document.querySelector(':root').style.setProperty('--main-color', dataColor);
    
    // Save the selected color to localStorage
    localStorage.setItem('selectedColor', dataColor);
  });
});

// Load the color from localStorage on page load
window.addEventListener('DOMContentLoaded', () => {
  const savedColor = localStorage.getItem('selectedColor');
  if (savedColor) {
    document.querySelector(':root').style.setProperty('--main-color', savedColor);
  }
});



// back to top js
var backtotop = $('.back2top');
var html_body = $('html,body');

backtotop.on('click',function(){
  html_body.animate({scrollTop:0},300);
});

$(window).on('scroll',function(){
var scrolliness = $(this).scrollTop();

if(scrolliness > 400){
  backtotop.show();
 }
else{
  backtotop.hide();
};
});




// type js
// var typed = new Typed('.type', {
//   strings: ['A Frontend Designer', 'A Web Developer'],
//   smartBackspace: true,
//   typeSpeed: 70,
//   startDelay: 50,
//   loop: true,
//   backDelay: 1000,
  
// });

// venubox js
new VenoBox({
  selector: '.venobox'
});

// // Enable multi-level dropdowns
document.addEventListener('DOMContentLoaded', function() {
  var dropdowns = document.querySelectorAll('.dropdown-item.dropdown');

  dropdowns.forEach(function(dropdown) {
      dropdown.addEventListener('mouseenter', function() {
          let nestedMenu = dropdown.querySelector('.dropdown-menu-nested');
          if (nestedMenu) {
              nestedMenu.style.display = 'block';
          }
      });
      
      dropdown.addEventListener('mouseleave', function() {
          let nestedMenu = dropdown.querySelector('.dropdown-menu-nested');
          if (nestedMenu) {
              nestedMenu.style.display = 'none';
          }
      });
  });
});

// single php page slider
$('.related-posts-slider').slick({
  slidesToShow: 3,
  slidesToScroll: 1,
  dots: true,
  arrows: true,
  infinite: true,
  centerMode: false,
  variableWidth: false,
  autoplay: true,
  autoplaySpeed: 3000,
  prevArrow: '<button  class="arrow-sbr-prev"><i class="fas fa-chevron-left"></i></button>',
  nextArrow: '<button  class="arrow-sbr-next"><i class="fas fa-chevron-right"></i></button>',
  responsive: [
      {
          breakpoint: 992,
          settings: {
              slidesToShow: 2
          }
      },
      {
          breakpoint: 768,
          settings: {
              slidesToShow: 1
          }
      }
  ]
});



/**
     * comment edit option customize
     */

    // Open edit popup
    $('.edit-comment').on('click', function(e) {
      e.preventDefault();

      var commentID = $(this).data('comment-id');
      var commentContent = $(this).closest('.comment-body').find('.comment-text').text().trim();

      $('#edit-comment-id').val(commentID);
      $('#edit-comment-content').val(commentContent);

      $('#edit-comment-popup').show();
  });

  // Close the popup
  $('#close-popup').on('click', function() {
      $('#edit-comment-popup').hide();
  });

  // Submit the edited comment
  $('#submit-edit-comment').on('click', function(e) {
      e.preventDefault();

      var commentID = $('#edit-comment-id').val();
      var commentContent = $('#edit-comment-content').val();

      $.ajax({
          url: ajax_object.ajax_url,
          type: 'POST',
          data: {
              action: 'update_comment',
              comment_id: commentID,
              comment_content: commentContent,
          },
          success: function(response) {
              if (response.success) {
                  // Update the comment content in the list
                  $('.comment[data-comment-id="' + commentID + '"]').find('.comment-text').text(commentContent);
                  // Hide the popup
                  $('#edit-comment-popup').hide();
              } else {
                  alert('Failed to update the comment.');
              }
          }
      });
  });
  /**
   * comment edit option customize end
   */


  // wp widget calendar script
  var slider = tns({
    container: '.testimonials_slide',
    speed: 300,
    autoplayTimeout: 3000,
    items: 1,
    autoplay: true,
    autoHeight: true,
    controls: false,
    nav: false,
    autoplayButtonOutput: false,
    prevButton: true,
    nextButton: true,
  });

  document.querySelector(".subscribe_form form").addEventListener("submit", function(event) {
    const emailInput = document.querySelector("input[name='email']");
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(emailInput.value)) {
        alert("Please enter a valid email address.");
        event.preventDefault(); // Stop form from submitting
    }
});


document.addEventListener('DOMContentLoaded', function () {
  const thumbnails = document.querySelectorAll('.product-thumbnails .thumbnail img');
  const mainImage = document.querySelector('.product-main-image img');

  thumbnails.forEach(function (thumbnail) {
      thumbnail.addEventListener('click', function () {
          const fullImage = this.getAttribute('data-full-image');
          if (mainImage) {
              mainImage.src = fullImage; // Change the main image to the full-size version
          }
      });
  });
});

// 404.php
document.addEventListener('DOMContentLoaded', function() {
  const errorPage = document.querySelector('.error-404');
  errorPage.style.opacity = 0;
  setTimeout(() => {
      errorPage.style.transition = 'opacity 1s ease';
      errorPage.style.opacity = 1;
  }, 500);
});


}(jQuery));
